/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dateformatter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.sun.org.apache.xerces.internal.impl.dv.xs.DateDV;

import sun.java2d.pipe.SpanShapeRenderer.Simple;

/**
 *
 * @author Vishal Kumar
 * 
 */
public class DateFormatter {
    
    /**
     * @param args the command line arguments
     */
   
    
  /**This is the main method in which we have created object of dat class*/
    public static void main(String[] args) {
        // TODO code application logic here
        dat obj1=new dat();
    }

    
    
}
/** This is the main class*/
class dat{
    /** The toDate method is converting string into the sql date */
public static Date toDate(String d)
	{
		/** here we have declare the sql date format */
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-d");
		java.util.Date date=null;
		/** we have put the code in try catch ,to handle the exception if any */
                try {
			date = dateFormat.parse(d);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Date sqlDate= new Date(date.getTime());
		
		/**The return method will return the sql date which is converted from the string */
                return sqlDate;
		
	}}

